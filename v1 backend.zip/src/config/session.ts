import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pg from "pg";
import { env } from "./env.js";

// A real, server-side session store (Postgres-backed, via the same
// database — no extra infra like Redis needed on Render) rather than a
// stateless JWT. This is deliberate: docs/API_DOCUMENTATION.md's Auth
// section requires that POST /api/auth/logout actually invalidate the
// session server-side, which a bare JWT can't do without its own
// blocklist. connect-pg-simple creates and manages its own `session`
// table automatically (see `createTableIfMissing` below) — it is not a
// Prisma model.
const PgSession = connectPgSimple(session);

const pgPool = new pg.Pool({ connectionString: env.DATABASE_URL });

export const sessionMiddleware = session({
  store: new PgSession({
    pool: pgPool,
    tableName: "session",
    createTableIfMissing: true,
  }),
  name: "journal_sid",
  secret: env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: env.SESSION_COOKIE_SECURE,
    // Cross-site (Vercel frontend, Render backend) requires SameSite=None
    // + Secure — browsers reject SameSite=None over plain HTTP, so this
    // only applies when SESSION_COOKIE_SECURE=true (i.e. production,
    // behind HTTPS). Local dev (both false) falls back to "lax", which is
    // fine since local dev is normally same-site (localhost:PORT).
    sameSite: env.SESSION_COOKIE_SECURE ? "none" : "lax",
    domain: env.SESSION_COOKIE_DOMAIN || undefined,
    maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
  },
});

declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}
